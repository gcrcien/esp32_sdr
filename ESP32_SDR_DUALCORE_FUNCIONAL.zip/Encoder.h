// Encoder.h
#ifndef ENCODER_H
#define ENCODER_H

#include "Config.h"
#include "Globals.h"
#include "Storage.h"
#include "Bands.h"

// vienen de otros headers / globals
extern const uint32_t STEP_TABLE[];
extern int g_stepIdx;

extern const uint32_t g_samplingTable[3];
extern int      g_samplingIndex;
extern uint32_t g_samplingHz;
void sdr_set_sampling(uint32_t hz);

// =====================================================
// 1) Encoder por LUT de 16 estados (original)
// =====================================================
volatile int8_t  g_enc_quarter  = 0;   // acumulador de “cuartos”
volatile uint8_t g_enc_prev     = 0;   // último estado A/B
volatile uint32_t g_enc_last_us = 0;   // antirrebote por tiempo

// LUT clásica
// idx = (oldA oldB newA newB)
static const int8_t ENC_LUT[16] = {
  0,  -1, +1,  0,
  +1,  0,  0, -1,
  -1,  0,  0, +1,
   0, +1, -1,  0
};

// =====================================================
// 2) ISR en A y en B
// =====================================================
void IRAM_ATTR enc_isr()
{
  uint32_t now = micros();
  // 120 us es lo que usabas al inicio; 500 us perdía pasos
  if ((now - g_enc_last_us) < 120) {
    return;
  }
  g_enc_last_us = now;

  uint8_t a = (uint8_t)digitalRead(ENC_A);
  uint8_t b = (uint8_t)digitalRead(ENC_B);

  uint8_t idx = (g_enc_prev << 2) | (a ? 1 : 0) | (b ? 2 : 0);
  int8_t  d   = ENC_LUT[idx];
  if (d != 0) {
    g_enc_quarter += d;
  }

  g_enc_prev = (a ? 1 : 0) | (b ? 2 : 0);
}

// =====================================================
// 3) Setup
// =====================================================
inline void enc_setup()
{
  pinMode(ENC_A, INPUT_PULLUP);
  pinMode(ENC_B, INPUT_PULLUP);
  pinMode(ENC_SW, INPUT_PULLUP);
  pinMode(BAND_SW_PIN, INPUT_PULLUP);
  pinMode(S1_PIN, INPUT_PULLUP);

  uint8_t a = (uint8_t)digitalRead(ENC_A);
  uint8_t b = (uint8_t)digitalRead(ENC_B);
  g_enc_prev = (a ? 1 : 0) | (b ? 2 : 0);

  attachInterrupt(digitalPinToInterrupt(ENC_A), enc_isr, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_B), enc_isr, CHANGE);
}

// =====================================================
// 4) Botón de banda: short → banda, long → modo IQ
// =====================================================
inline void enc_pollBandButton()
{
  static int      prevBtn   = HIGH;
  static uint32_t pressMs   = 0;
  static bool     longFired = false;

  int nowBtn = digitalRead(BAND_SW_PIN);

  if (prevBtn == HIGH && nowBtn == LOW) {
    pressMs   = millis();
    longFired = false;
  }

  if (prevBtn == LOW && nowBtn == LOW) {
    if (!longFired && (millis() - pressMs) >= BAND_LONG_MS) {
      longFired = true;
      // long press → ciclo de modos
      g_encMode++;
      if (g_encMode > ENC_MODE_IQ_PHASE)
        g_encMode = ENC_MODE_NORMAL;
    }
  }

  if (prevBtn == LOW && nowBtn == HIGH) {
    uint32_t dur = millis() - pressMs;
    if (dur < BAND_LONG_MS && !longFired) {
      // short press → siguiente banda
      bands_next_band();
      ui_drawBandBar();
    }
  }

  prevBtn = nowBtn;
}

// =====================================================
// 5) Poll del encoder
// =====================================================
inline void enc_pollEncoder()
{
  // ----- A) TAP en S1 → cambiar sample rate -----
  {
    static bool     s1Prev = false;
    static uint32_t s1Down = 0;
    bool s1Now = (digitalRead(S1_PIN) == LOW);

    if (!s1Prev && s1Now) {
      // bajada
      s1Down = millis();
    }
    if (s1Prev && !s1Now) {
      // subida → ¿tap corto?
      uint32_t dur = millis() - s1Down;
      if (dur < 250) {
        // tap corto → rotar sampleo
        g_samplingIndex++;
        if (g_samplingIndex >= 3) g_samplingIndex = 0;
        g_samplingHz = g_samplingTable[g_samplingIndex];
        sdr_set_sampling(g_samplingHz);
      }
    }
    s1Prev = s1Now;
  }

  // ----- B) sacar los “cuartos” que juntó la ISR -----
  int8_t quarters;
  noInterrupts();
  quarters = g_enc_quarter;
  g_enc_quarter = 0;
  interrupts();

  // 4 transiciones = 1 paso real de usuario
  long steps = quarters / 4;

  bool s1Pressed = (digitalRead(S1_PIN) == LOW);

  // ----- C) aplicar pasos -----
  if (steps != 0) {

    // ===== modo normal =====
    if (g_encMode == ENC_MODE_NORMAL) {

      if (s1Pressed) {
        // === mover REFERENCIA ===
        // rango pedido: 200k .. 40M, paso 200k
        int32_t delta = steps * 200000L;    // 200 kHz por tick
        int64_t nr    = (int64_t)g_refMag + delta;
        if (nr < 200000L)    nr = 200000L;
        if (nr > 40000000L)  nr = 40000000L;
        ee_set_ref((uint32_t)nr);

      } else {
        // === mover FRECUENCIA ===
    uint32_t st = STEP_TABLE[g_stepIdx];
    int64_t nf  = (int64_t)g_loHz + (int64_t)steps * (int64_t)st;
    if (nf < 5000000L)   nf = 5000000L;
    if (nf > 31000000L)  nf = 31000000L;
    uint32_t finalHz = (uint32_t)nf;
    ee_set_lo(finalHz);
    int oldIdx = g_bandIndex;
    bands_select_from_lo(finalHz);
    if (g_bandIndex != oldIdx) {
      ui_drawBandBar();
    }
      }

    // ===== modo IQ GAIN =====
    } else if (g_encMode == ENC_MODE_IQ_GAIN) {
      g_iqGain += steps * 0.01;
      if (g_iqGain < 0.50) g_iqGain = 0.50;
      if (g_iqGain > 1.50) g_iqGain = 1.50;
      ee_set_iq_gain(g_iqGain);

    // ===== modo IQ PHASE =====
    } else {
      g_iqPhase += steps * 0.01;
      if (g_iqPhase < -0.50) g_iqPhase = -0.50;
      if (g_iqPhase >  0.50) g_iqPhase =  0.50;
      ee_set_iq_phase(g_iqPhase);
    }
  }

  // ----- D) botón del encoder → cambiar STEP -----
  static bool prevEncBtn = false;
  bool encBtn = (digitalRead(ENC_SW) == LOW);
  if (encBtn && !prevEncBtn) {
    if (g_encMode == ENC_MODE_NORMAL && !s1Pressed) {
      g_stepIdx++;
      if (g_stepIdx >= (int)(sizeof(STEP_TABLE)/sizeof(STEP_TABLE[0]))) {
        g_stepIdx = 0;
      }
    }
  }
  prevEncBtn = encBtn;
}

#endif // ENCODER_H
