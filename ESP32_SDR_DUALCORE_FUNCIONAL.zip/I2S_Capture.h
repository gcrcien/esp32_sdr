// I2S_Capture.h — captura I2S con doble buffer para 2 cores (robusta a 24k)
#ifndef I2S_CAPTURE_H
#define I2S_CAPTURE_H

#include "Config.h"
#include <driver/i2s.h>
#include <math.h>

// mismo que antes
#define I2S_DEFAULT_RL      1
#define SWAP_IQ             1

// ==================== buffers compartidos ====================
static double g_iqBufR[2][NUM_SAMPLES];
static double g_iqBufI[2][NUM_SAMPLES];
static volatile int  g_iq_wr_idx      = 0;
static volatile int  g_iq_latest_idx  = -1;
static volatile bool g_iq_has_frame   = false;
// contador de frames capturados (para la UI)
static volatile uint32_t g_iq_frame_counter = 0;

// ==================== setup I2S ====================
inline void i2s_setup()
{
  i2s_config_t i2s_config = {
    .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_RX),
    .sample_rate = (uint32_t)g_samplingHz,
    .bits_per_sample = I2S_BITS_PER_SAMPLE_32BIT,
    .channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT,
    .communication_format = I2S_COMM_FORMAT_I2S,
    .intr_alloc_flags = 0,
    .dma_buf_count = 4,
    .dma_buf_len = 512,
    .use_apll = USE_APLL,
    .tx_desc_auto_clear = true,
    .fixed_mclk = 0
  };

  i2s_pin_config_t pin_config = {
    .bck_io_num   = I2S_BCK_PIN,
    .ws_io_num    = I2S_LRCK_PIN,
    .data_out_num = -1,
    .data_in_num  = I2S_DATA_PIN
  };

  i2s_driver_install(I2S_PORT, &i2s_config, 0, NULL);
  i2s_set_pin(I2S_PORT, &pin_config);
  i2s_set_clk(I2S_PORT, g_samplingHz,
              I2S_BITS_PER_SAMPLE_32BIT,
              I2S_CHANNEL_STEREO);
  i2s_start(I2S_PORT);
  i2s_zero_dma_buffer(I2S_PORT);
}

// cambiar Fs desde fuera
inline void sdr_set_sampling_from_index(int idx)
{
  int maxIdx = (int)(sizeof(g_samplingTable)/sizeof(g_samplingTable[0])) - 1;
  if (idx < 0) idx = 0;
  if (idx > maxIdx) idx = maxIdx;

  g_samplingIndex = idx;
  uint32_t hz = g_samplingTable[g_samplingIndex];

  i2s_set_clk(I2S_PORT,
              hz,
              I2S_BITS_PER_SAMPLE_32BIT,
              I2S_CHANNEL_STEREO);

  g_samplingHz      = hz;
  g_samplingChanged = true;   // <- la UI lo va a ver
}

// ==================== captura IQ (core 1) ====================
inline void i2s_captureIQ()
{
  const int frames          = NUM_SAMPLES;   // 512
  const int bytes_per_frame = 8;             // L+R en 32 bits
  const int total_bytes     = frames * bytes_per_frame;

  static uint8_t i2s_data[NUM_SAMPLES * 8];

  // tiempo que tarda en llegar un frame completo a la Fs actual
  // frame_time_ms ≈ (NUM_SAMPLES / Fs) * 1000
  float frame_time_ms_f = (1000.0f * (float)NUM_SAMPLES) / (float)g_samplingHz;
  // le damos margen (x3) para 24k y WiFi espurios
  uint32_t rd_timeout_ms = (uint32_t)(frame_time_ms_f * 3.0f);
  if (rd_timeout_ms < 5)   rd_timeout_ms = 5;
  if (rd_timeout_ms > 100) rd_timeout_ms = 100;

  size_t remaining = total_bytes;
  uint8_t *p       = i2s_data;

  while (remaining > 0) {
    size_t br = 0;
    esp_err_t err = i2s_read(
        I2S_PORT,
        p,
        remaining,
        &br,
        pdMS_TO_TICKS(rd_timeout_ms)
    );
    if (err != ESP_OK) {
      // si falló la lectura, no publicamos frame nuevo
      return;
    }
    if (br == 0) {
      // timeout sin datos
      return;
    }
    remaining -= br;
    p         += br;
  }

  // llegamos aquí con el frame COMPLETO
  int wr = g_iq_wr_idx;
  double *dstR = g_iqBufR[wr];
  double *dstI = g_iqBufI[wr];

  int32_t *w = (int32_t *)i2s_data;

  static bool autodetect_done = false;
  static bool data_is_RL      = (I2S_DEFAULT_RL != 0);

  // autodetección
  {
    int32_t t0 = w[0] >> 8;
    int32_t t1 = w[1] >> 8;
    if (!autodetect_done) {
      if (t0 == t1) {
        data_is_RL = false;
      }
      autodetect_done = true;
    }
  }

  double accI = 0.0, accQ = 0.0;

  for (int n = 0; n < frames; n++) {
    int32_t w0 = w[n*2 + 0] >> 8;
    int32_t w1 = w[n*2 + 1] >> 8;

    int32_t sL, sR;
    if (data_is_RL) {
      sR = w0;
      sL = w1;
    } else {
      sL = w0;
      sR = w1;
    }

    double sI, sQ;
#if SWAP_IQ
    sI = (double)sR;
    sQ = (double)sL;
#else
    sI = (double)sL;
    sQ = (double)sR;
#endif

    dstR[n] = sI;
    dstI[n] = sQ;

    accI += sI;
    accQ += sQ;
  }

  // quitar DC del frame
  double meanI = accI / frames;
  double meanQ = accQ / frames;
  for (int n = 0; n < frames; n++) {
    dstR[n] -= meanI;
    dstI[n] -= meanQ;
  }

  // publicar
  g_iq_latest_idx  = wr;
  g_iq_has_frame   = true;
  g_iq_frame_counter++;
  g_iq_wr_idx      = wr ^ 1;   // siguiente
}

// ==================== API para la UI (core 0) ====================
inline bool i2s_copy_latest_iq(double *dstR, double *dstI, uint32_t &outFrameId)
{
  if (!g_iq_has_frame) return false;
  int rd = g_iq_latest_idx;
  if (rd < 0 || rd > 1) return false;

  memcpy(dstR, g_iqBufR[rd], sizeof(double) * NUM_SAMPLES);
  memcpy(dstI, g_iqBufI[rd], sizeof(double) * NUM_SAMPLES);
  outFrameId = g_iq_frame_counter;
  return true;
}

#endif
